#ifndef MAC_H
#define MAC_H

#include    <stdint.h>

/* wii index, do not change */
const uint8_t wii_nr = 1;
/* mac address of wiimote, adapt if needed */
const uint8_t wii_mac[6] = { 0x58, 0xbd, 0xa3, 0x54, 0xfb, 0xaa };

#endif
