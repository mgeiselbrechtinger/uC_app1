#ifndef __FONT5X7_H__
#define __FONT5X7_H__

#include "font.h"

extern const font Standard5x7;

#endif

