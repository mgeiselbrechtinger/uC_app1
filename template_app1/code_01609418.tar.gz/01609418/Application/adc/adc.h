#ifndef ADC_H
#define ADC_H

/**
 * Initializes the hardware of the adc
 *
 * @HW: ADC, TIMER0
 */
void adcInit(void);

#endif
